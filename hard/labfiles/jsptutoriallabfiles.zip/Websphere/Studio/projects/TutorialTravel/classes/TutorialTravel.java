/**
* The XtremeTravel Travel Application variation used
* in JSP development tutorial
*/

import java.io.*;
import java.beans.Beans;

import javax.servlet.*;
import javax.servlet.http.*;
import com.sun.server.http.*;
import com.ibm.servlet.personalization.sessiontracking.*;

public class TutorialTravel extends HttpServlet {

   public void doGet(HttpServletRequest request, HttpServletResponse response)
                     throws ServletException,  IOException {
      doPost(request, response);
   }

   public void doPost(HttpServletRequest request, HttpServletResponse response)
                     throws ServletException,  IOException {

 	   String first=request.getParameterValues("firstname")[0];
	   String last=request.getParameterValues("lastname")[0];
      String sport=request.getParameterValues("sportChoice")[0];
         // Grab a session (probably new)
      IBMSessionData session = (IBMSessionData)request.getSession(true);
         // Save the entered username into the session object
      session.setUserName(first + " " + last);

         // Return a Web page using callPage -- choose page based on selected sport
      HttpServiceResponse res = (HttpServiceResponse)response;
      if ("Xtreme Rock Climbing".equals(sport)) {
         res.callPage("/TutorialTravel/rock-1.jsp", request);
      }
      else {
         res.callPage("/TutorialTravel/ski-1.jsp", request);
      }
   }

}
