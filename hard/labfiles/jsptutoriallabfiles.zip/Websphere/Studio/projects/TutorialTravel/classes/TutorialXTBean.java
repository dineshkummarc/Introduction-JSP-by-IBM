/**
 *  This class wraps the state information contained within the TutorialTravel
 *  login form!
 */
public class TutorialXTBean implements java.io.Serializable {

  private String fLastname;
  private String fFirstname;
  private String fStreet;
  private String fCity;
  private String fState;
  private String fZip;
  private String fSport;

  public void setLastname(String s) { fLastname = s; }
  public String getLastname() { return fLastname; }

  public void setFirstname(String s) { fFirstname = s; }
  public String getFirstname() { return fFirstname; }

  public void setStreet(String s) { fStreet = s; }
  public String getStreet() { return fStreet; }

  public void setCity(String s) { fCity = s; }
  public String getCity() { return fCity; }

  public void setState(String s) { fState = s; }
  public String getState() { return fState; }

  public void setZip(String s) { fZip = s; }
  public String getZip() { return fZip; }

  public void setSportChoice(String s) { fSport = s; }
  public String getSportChoice() { return fSport; }
}

