
import java.awt.*;
import java.io.*;


public class BannerAdBean implements java.io.Serializable {

   private String fImagePath = "";
   private String fImageName = "";
   private String fAdURL = "";
   private int    fWidth=0, fHeight=0;

   public String getImageName() { return fImageName; }
   public void setImageName(String image) { 
		fImageName = image; 
		//setDimension(); 
	}

   public String getImagePath() { return fImagePath; }
   public void setImagePath(String path) { fImagePath = path; }

   public String getAdURL() { return fAdURL; }
   public void setAdURL(String URL) { fAdURL = URL; }

   public int getWidth() { return fWidth; }
   public void setWidth(int width) { fWidth = width; }

   public int getHeight() { return fHeight; }
   public void setHeight(int height) { fHeight = height; }

   public String getAdHTML() {
      return "<a href=" + fAdURL + "><IMG src=" + fImagePath + fImageName +
              //" width=" + fWidth + " height=" + fHeight +
              "></a>";
   }

   private void setDimension() {
      Canvas canvas = new Canvas();
      MediaTracker tracker = new MediaTracker(canvas);
      Toolkit tk = Toolkit.getDefaultToolkit();
      Image theImage = tk.getImage(fImageName);
      tk.prepareImage(theImage, -1, -1, canvas);
      tracker.addImage(theImage, 0);
      try {
         tracker.waitForID(0);
         fWidth = theImage.getWidth(canvas);
         fHeight = theImage.getHeight(canvas);
      } catch (InterruptedException e) { e.printStackTrace(System.out); }
   }

   public BannerAdBean() { }

   public BannerAdBean(String AdUrl, String Imagepath, String ImageFilename) {
      setAdURL(AdUrl);
      setImagePath(Imagepath);
      setImageName(ImageFilename);
   }

   public static void main(String[] args) {
      if (args.length != 4) {
         System.err.println("Usage: BannerAdBean AdURL imagepath imagefilename beanOutputfilename");
         System.exit(1);
      }
      BannerAdBean newBean = new BannerAdBean(args[0], args[1], args[2]);
      try {
         ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(args[3]));
         stream.writeObject(newBean);
         stream.close();
      } catch (IOException e) { e.printStackTrace(System.err); }
      System.exit(0);
   }
}
